package com.example.submissonawalintermediate.API

import com.example.submissonawalintermediate.Response.ResponseLogin
import com.example.submissonawalintermediate.Response.ResponseMaps
import com.example.submissonawalintermediate.Response.ResponseRegister
import com.example.submissonawalintermediate.Response.ResponseStory
import com.example.submissonawalintermediate.Response.UploadFileResponse
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Call
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.Part
import retrofit2.http.Query

interface ApiService {
    @FormUrlEncoded
    @POST("login")
    fun login(
        @Field("email") email: String,
        @Field("password") password: String
    ): Call<ResponseLogin>

    @FormUrlEncoded
    @POST("register")
    fun register(
        @Field("name") name : String?,
        @Field("email") email : String?,
        @Field("password") password : String?
    ): Call<ResponseRegister>

    @GET("stories")
    suspend fun getStory(
        @Header("Authorization") auth: String,
        @Query("page") page: Int,
        @Query("size") size: Int
    ): ResponseStory

    @Multipart
    @POST("stories")
    fun postStory(
        @Header("Authorization") auth : String,
        @Part file: MultipartBody.Part,
        @Part("description") description: RequestBody,
        @Part("lat") lat: RequestBody,
        @Part("lon") lon: RequestBody
    ): Call<UploadFileResponse>

    @GET("stories")
    fun getStoryMaps(
        @Header("Authorization") auth : String,
        @Query("location") location: Int=1
    ): Call<ResponseMaps>
}