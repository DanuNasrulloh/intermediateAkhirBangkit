package com.example.submissonawalintermediate.value

object Determination_Value {
    const val MIN_LENGTH_PASSWORD = 8
}