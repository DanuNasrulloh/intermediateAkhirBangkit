package com.example.submissonawalintermediate.my_database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.submissonawalintermediate.Response.Story

@Database(
    entities = [Story::class, keyRemote::class],
    version = 1,
    exportSchema = false
)
abstract class Database_story : RoomDatabase() {

    abstract fun daoStory() : DaoStory
    abstract fun keyremoteDao() : keyRemoteDao

    companion object{
        @Volatile
        private var INSTANCE: Database_story? = null

        @JvmStatic
        fun getDatabase(context: Context) : Database_story {
            return INSTANCE ?: synchronized(this){
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    Database_story::class.java, "storyOfdatabase"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                    .also{ INSTANCE = it}
            }
        }
    }
}