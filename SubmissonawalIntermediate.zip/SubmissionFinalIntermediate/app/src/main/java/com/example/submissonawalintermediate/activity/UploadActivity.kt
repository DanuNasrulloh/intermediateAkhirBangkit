package com.example.submissonawalintermediate.activity

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.ViewModelProvider
import com.example.submissonawalintermediate.User.UserPreferences
import com.example.submissonawalintermediate.ViewModel.ViewModelFactory
import com.example.submissonawalintermediate.ViewModel.ViewModelUpload
import com.example.submissonawalintermediate.utils.createCustomTempFile
import com.example.submissonawalintermediate.utils.reduceFileImage
import com.example.submissonawalintermediate.utils.uriToFile
import com.example.submissonawalintermediate.MainActivity
import com.example.submissonawalintermediate.R
import com.example.submissonawalintermediate.databinding.ActivityUploadBinding
import com.google.android.gms.location.LocationServices
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File

class UploadActivity : AppCompatActivity() {

    private lateinit var binding: ActivityUploadBinding
    private lateinit var uploadViewModel: ViewModelUpload
    private var latitude: Double? = null
    private var longitude: Double? = null
    private val dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

    companion object {
        private val REQUIRED_PERMISSIONS = arrayOf(Manifest.permission.CAMERA)
        private const val REQUEST_CODE_PERMISSIONS = 10
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityUploadBinding.inflate(layoutInflater)
        setContentView(binding.root)

        uploadViewModel = ViewModelProvider(this, ViewModelFactory(UserPreferences.getInstance(dataStore)))[ViewModelUpload::class.java]

        if (!allPermissionGranted()) {
            ActivityCompat.requestPermissions(this, REQUIRED_PERMISSIONS, REQUEST_CODE_PERMISSIONS)
        }

        initializeUI()
    }

    private fun initializeUI() {
        binding.cameraButton.setOnClickListener { startTakePhoto() }
        binding.galleryButton.setOnClickListener { startGallery() }
        binding.uploadButton.setOnClickListener { handleUploadButtonClick() }
        binding.locationSwitch.isChecked = true
        if (binding.locationSwitch.isChecked) {
            getCurrentLocation()
        }
        binding.locationSwitch.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                getCurrentLocation()
            } else {
                latitude = null
                longitude = null
            }
        }
    }

    private fun handleUploadButtonClick() {
        val desc = binding.description.text
        val photo = getFile
        if (photo != null && desc != null) {
            showLoading(true)
            uploadImage()
        } else {
            showLoading(false)
            Toast.makeText(this@UploadActivity, "Silahkan masukkan file dan deskripsi", Toast.LENGTH_SHORT).show()
        }
        observeUploadResult()
    }

    private fun observeUploadResult() {
        uploadViewModel.getStory().observe(this) {
            if (it != null) {
                showLoading(true)
                Toast.makeText(this@UploadActivity, it.message, Toast.LENGTH_SHORT).show()
                val intent = Intent(this@UploadActivity, MainActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
                startActivity(intent)
                finish()
            }
        }
    }

    @SuppressLint("QueryPermissionsNeeded")
    private fun startTakePhoto() {
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        intent.resolveActivity(packageManager)

        createCustomTempFile(application).also {
            val photoURI: Uri = FileProvider.getUriForFile(this@UploadActivity, "com.example.submissonawalintermediate", it)
            currentPhotoPath = it.absolutePath
            intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI)
            launcherIntentCamera.launch(intent)
        }
    }

    private fun startGallery() {
        val intent = Intent()
        intent.action = Intent.ACTION_GET_CONTENT
        intent.type = "image/*"
        val chooser = Intent.createChooser(intent, "Choose a Picture")
        launcherIntentGallery.launch(chooser)
    }

    private fun uploadImage() {
        if (getFile != null) {
            uploadViewModel.getUser().observe(this) {
                val file = reduceFileImage(getFile as File)
                val description = binding.description.text.toString().toRequestBody("text/plain".toMediaType())
                val requestImageFile = file.asRequestBody("image/jpeg".toMediaTypeOrNull())
                val imageMultipart: MultipartBody.Part = MultipartBody.Part.createFormData(
                    "photo",
                    file.name,
                    requestImageFile
                )
                val latRequestBody = latitude?.toString()?.toRequestBody("text/plain".toMediaTypeOrNull())
                val lonRequestBody = longitude?.toString()?.toRequestBody("text/plain".toMediaTypeOrNull())
                if (latRequestBody != null && lonRequestBody != null) {
                    uploadViewModel.setPostStory(it.token, imageMultipart, description, latRequestBody, lonRequestBody)
                } else {
                    Toast.makeText(this@UploadActivity, "Latitude atau Longitude tidak tersedia", Toast.LENGTH_SHORT).show()
                }
            }
        } else {
            Toast.makeText(this@UploadActivity, "Silahkan masukkan file gambar anda", Toast.LENGTH_SHORT).show()
        }
    }

    private fun getCurrentLocation() {
        val fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED &&
            ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                100
            )
            return
        }
        fusedLocationClient.lastLocation.addOnSuccessListener { location ->
            if (location != null) {
                latitude = location.latitude
                longitude = location.longitude
            } else {
                Toast.makeText(this, getString(R.string.pesan_gagal), Toast.LENGTH_SHORT)
                    .show()
            }
        }
    }

    private var getFile: File? = null
    private lateinit var currentPhotoPath: String
    private val launcherIntentCamera = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == RESULT_OK) {
            val myFile = File(currentPhotoPath)
            getFile = myFile

            val result = BitmapFactory.decodeFile(getFile?.path)

            binding.ImageView.setImageBitmap(result)
        }
    }

    private val launcherIntentGallery = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK) {
            val selectedImg: Uri = result.data?.data as Uri

            contentResolver
            val myFile = uriToFile(selectedImg, this@UploadActivity)

            getFile = myFile

            binding.ImageView.setImageURI(selectedImg)
        }
    }

    private fun showLoading(loading: Boolean) {
        binding.progressBar.visibility = if (loading) View.VISIBLE else View.GONE
    }

    private fun allPermissionGranted() = REQUIRED_PERMISSIONS.all {
        ContextCompat.checkSelfPermission(baseContext, it) == PackageManager.PERMISSION_GRANTED
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CODE_PERMISSIONS) {
            if (!allPermissionGranted()) {
                Toast.makeText(this, "Tidak mendapatkan izin akses.", Toast.LENGTH_SHORT).show()
                finish()
            }
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        return false
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return super.onOptionsItemSelected(item)
    }
}