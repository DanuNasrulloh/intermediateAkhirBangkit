package com.example.submissonawalintermediate.activity

import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.example.submissonawalintermediate.databinding.ActivityDetailBinding


class DetailActivity : AppCompatActivity() {

    private lateinit var binding : ActivityDetailBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val name = intent.getStringExtra(NAME)
        val desc = intent.getStringExtra(DESC)
        val photo = intent.getStringExtra(URL)

        binding.description.text = desc
        binding.userName.text = name
        Glide.with(this@DetailActivity)
            .load(photo)
            .transition(DrawableTransitionOptions.withCrossFade())
            .centerCrop()
            .into(binding.avatarUser)

    }
    companion object {
        const val NAME = "name"
        const val DESC = "deskripsi"
        const val URL = "url"
    }
}