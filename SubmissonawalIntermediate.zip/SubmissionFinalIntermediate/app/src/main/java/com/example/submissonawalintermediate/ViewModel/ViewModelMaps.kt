package com.example.submissonawalintermediate.ViewModel

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import com.example.submissonawalintermediate.API.ApiConfig
import com.example.submissonawalintermediate.Response.MapsStory
import com.example.submissonawalintermediate.Response.ResponseMaps
import com.example.submissonawalintermediate.User.ModelUser
import com.example.submissonawalintermediate.User.UserPreferences
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ViewModelMaps(private val pref: UserPreferences) : ViewModel() {

    val data = MutableLiveData<ArrayList<MapsStory>>()

    fun getMapsStory(token: String) {
        val retro = ApiConfig.getApiService().getStoryMaps("Bearer $token")
        retro.enqueue(object : Callback<ResponseMaps> {
            override fun onResponse(call: Call<ResponseMaps>, response: Response<ResponseMaps>) {
                if (response.isSuccessful) {
                    data.postValue(response.body()?.listStory as ArrayList<MapsStory>)
                    Log.d("Result MapsModel : ", (response.body()?.listStory as List<MapsStory>).toString())
                } else {
                    Log.d("Error : ", response.message().toString())
                }
            }

            override fun onFailure(call: Call<ResponseMaps>, t: Throwable) {
                Log.d("onFailure", t.message!!)
            }
        })
    }

    fun getUser(): LiveData<ModelUser> {
        return pref.getUser().asLiveData()
    }

    fun getMaps(): LiveData<ArrayList<MapsStory>> {
        return data
    }
}