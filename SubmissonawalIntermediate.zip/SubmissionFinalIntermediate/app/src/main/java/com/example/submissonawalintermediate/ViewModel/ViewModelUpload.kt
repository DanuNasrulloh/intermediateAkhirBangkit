package com.example.submissonawalintermediate.ViewModel

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import com.example.submissonawalintermediate.API.ApiConfig
import com.example.submissonawalintermediate.Response.UploadFileResponse
import com.example.submissonawalintermediate.User.ModelUser
import com.example.submissonawalintermediate.User.UserPreferences
import kotlinx.coroutines.launch
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ViewModelUpload (private val pref: UserPreferences): ViewModel() {

    val data = MutableLiveData<UploadFileResponse>()

    fun setPostStory(token: String, image: MultipartBody.Part, desc: RequestBody, lat: RequestBody, lon: RequestBody) {
        val service = ApiConfig.getApiService().postStory("Bearer $token", image, desc, lat, lon)
        service.enqueue(object : Callback<UploadFileResponse> {
            override fun onResponse(call: Call<UploadFileResponse>, response: Response<UploadFileResponse>) {
                if (response.isSuccessful) {
                    data.postValue(response.body())
                    response.body()?.message?.let {
                        Log.d("RESULT POST :", it)
                    }
                }
            }
            override fun onFailure(call: Call<UploadFileResponse>, t: Throwable) {
                Log.d("Error :", t.message!!)
            }
        })
        }



    fun getUser(): LiveData<ModelUser> {
        return pref.getUser().asLiveData()
    }
    fun getStory(): LiveData<UploadFileResponse> {
        return data
    }
}