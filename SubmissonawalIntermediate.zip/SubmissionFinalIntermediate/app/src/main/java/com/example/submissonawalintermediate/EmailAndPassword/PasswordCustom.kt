package com.example.submissonawalintermediate.EmailAndPassword

import android.content.Context
import android.graphics.Canvas
import android.text.Editable
import android.text.TextWatcher
import android.util.AttributeSet
import android.view.View
import androidx.appcompat.widget.AppCompatEditText
import com.example.submissonawalintermediate.utils.validateMinLegth

class PasswordCustom: AppCompatEditText {
    constructor(context: Context): super(context){
        init()
    }

    constructor(context: Context, attrs: AttributeSet) : super(context, attrs) {
        init()
    }

    constructor(context: Context, attrs: AttributeSet, defStyleAttr: Int) : super(context, attrs, defStyleAttr) {
        init()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        hint = "Password"
        textAlignment = View.TEXT_ALIGNMENT_VIEW_START
    }

    private fun init() {
        addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                if (validateMinLegth(text.toString())) {
                    this@PasswordCustom.error = null
                    if (s.isEmpty()) {
                        error = "Password tidak boleh kosong"
                    }
                }
                else {
                    this@PasswordCustom.error = "Email tidak boleh kurang dari 8"
                }
            }
            override fun afterTextChanged(s: Editable) {}
        })
    }
}