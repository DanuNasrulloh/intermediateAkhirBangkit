package com.example.submissonawalintermediate.Story

import androidx.lifecycle.LiveData
import androidx.paging.ExperimentalPagingApi
import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.PagingData
import androidx.paging.liveData
import com.example.submissonawalintermediate.API.ApiService
import com.example.submissonawalintermediate.Response.Story
import com.example.submissonawalintermediate.my_database.Database_story

class Story_repo private constructor(
    private val storyDatabase: Database_story,
    private val apiService: ApiService
) {
    @OptIn(ExperimentalPagingApi::class)
    fun getStory(token: String): LiveData<PagingData<Story>> {
        return Pager(
            config = PagingConfig(pageSize = 5),
            remoteMediator = StoryMediatorRemote(storyDatabase, apiService, token),
            pagingSourceFactory = { storyDatabase.daoStory().getAllStory() }
        ).liveData
    }

    companion object {
        @Volatile
        private var INSTANCE: Story_repo? = null

        fun getInstance(
            apiService: ApiService,
            storyDatabase: Database_story
        ): Story_repo = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Story_repo(storyDatabase, apiService)
        }.also { INSTANCE = it }
    }
}