package com.example.submissonawalintermediate.activity

import android.content.Context
import android.os.Bundle
import android.util.Log
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.ViewModelProvider
import com.example.submissonawalintermediate.R
import com.example.submissonawalintermediate.User.UserPreferences
import com.example.submissonawalintermediate.ViewModel.ViewModelFactory
import com.example.submissonawalintermediate.ViewModel.ViewModelMaps
import com.example.submissonawalintermediate.databinding.ActivityMapsBinding
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions

class MapsActivity :AppCompatActivity(), OnMapReadyCallback {

    private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "login")

    private lateinit var binding: ActivityMapsBinding
    private lateinit var mapsViewModel: ViewModelMaps
    private lateinit var googleMap: GoogleMap

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMapsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.title = "Story Maps"

        mapsViewModel = ViewModelProvider(this, ViewModelFactory(UserPreferences.getInstance(dataStore)))[ViewModelMaps::class.java]

        mapsViewModel.getUser().observe(this) { user ->
            Log.d("result main maps :", user.token)
            mapsViewModel.getMapsStory(user.token)
        }
        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.mapGoggle) as SupportMapFragment
        mapFragment.getMapAsync(this)
    }

    override fun onMapReady(googleMap: GoogleMap) {
        this.googleMap = googleMap
        googleMap.uiSettings.isZoomControlsEnabled = true
        mapsViewModel.getMaps().observe(this) {
            if (it.isNotEmpty()) {
                for (i in it) {
                    googleMap.addMarker(MarkerOptions().position(LatLng(i.lat,i.lon)).title(i.name).snippet(i.description))
                    googleMap.moveCamera(CameraUpdateFactory.newLatLng(LatLng(i.lat, i.lon)))
                }
            }
        }
    }
}
//ddd