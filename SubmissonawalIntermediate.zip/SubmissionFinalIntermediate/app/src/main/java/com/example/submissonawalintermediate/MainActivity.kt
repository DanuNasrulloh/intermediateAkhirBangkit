package com.example.submissonawalintermediate

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.submissonawalintermediate.ViewModel.ViewModelFactory
import com.example.submissonawalintermediate.ViewModel.ViewModelMain
import com.example.submissonawalintermediate.Adapter.Adapter
import com.example.submissonawalintermediate.Adapter.AdapterLoadingState
import com.example.submissonawalintermediate.Adapter.AdapterStoryList
import com.example.submissonawalintermediate.Response.Story
import com.example.submissonawalintermediate.User.UserPreferences
import com.example.submissonawalintermediate.activity.DetailActivity
import com.example.submissonawalintermediate.activity.LoginActivity
import com.example.submissonawalintermediate.activity.MapsActivity
import com.example.submissonawalintermediate.activity.UploadActivity
import com.example.submissonawalintermediate.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private val dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

    private lateinit var binding : ActivityMainBinding
    private lateinit var mainViewModel: ViewModelMain
    private lateinit var adapter: AdapterStoryList

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.IDStory.layoutManager = LinearLayoutManager(this)
        adapter = AdapterStoryList()

        supportActionBar?.title = "Story App"

        mainViewModel = ViewModelProvider(this,
            ViewModelMain.ViewModelFactory(
                this,
                UserPreferences.getInstance(dataStore)
            )
        )[ViewModelMain::class.java]

        mainViewModel.getUser().observe(this) { user ->
            if (user.token.isNotEmpty()) {
                binding.IDStory.adapter = adapter.withLoadStateFooter(
                    footer = AdapterLoadingState {
                        adapter.retry()
                    }
                )
                mainViewModel.getStoryPage(user.token).observe(this){
                    adapter.submitData(lifecycle, it)
                }
                Log.d("result main :", user.token)
            } else {
                startActivity(Intent(this, LoginActivity::class.java))
                finish()
            }
        }

        binding.apply {
            IDStory.layoutManager = LinearLayoutManager(this@MainActivity)
            IDStory.setHasFixedSize(true)
            IDStory.adapter = adapter
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId) {
            R.id.Maps -> {
                Intent(this, MapsActivity::class.java).also {
                    startActivity(it)
                    Toast.makeText(this,"Maps", Toast.LENGTH_SHORT).show()
                }
            }
            R.id.upload-> {
                Intent(this, UploadActivity::class.java).also {
                    startActivity(it)
                    Toast.makeText(this,"Add Story", Toast.LENGTH_SHORT).show()
                }
            }
            R.id.logout -> {
                Intent(this, LoginActivity::class.java).also {
                    startActivity(it)
                    Toast.makeText(this,"Logout", Toast.LENGTH_SHORT).show()
                    mainViewModel.logout()
                }
            }
        }
        return super.onOptionsItemSelected(item)
    }
}
//alhamdullilah done