package com.example.submissonawalintermediate.ViewModel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.submissonawalintermediate.ViewModel.ViewModelLogin
import com.example.submissonawalintermediate.ViewModel.ViewModelUpload
import com.example.submissonawalintermediate.User.UserPreferences

class ViewModelFactory(private val pref: UserPreferences) : ViewModelProvider.NewInstanceFactory() {

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return when {
            modelClass.isAssignableFrom(ViewModelLogin::class.java) -> {
                ViewModelLogin(pref) as T
            }
            modelClass.isAssignableFrom(ViewModelUpload::class.java) -> {
                ViewModelUpload(pref) as T
            }
            modelClass.isAssignableFrom(ViewModelMaps::class.java) -> {
                ViewModelMaps(pref) as T
            }
            else -> throw IllegalArgumentException("Unknown ViewModel class: " + modelClass.name)
        }
    }
}