package com.example.submissonawalintermediate.my_database

import androidx.paging.PagingSource
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.submissonawalintermediate.Response.Story

@Dao
interface DaoStory {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStory(story: List<Story>)

    @Query("SELECT * FROM Story")
    fun getAllStory(): PagingSource<Int, Story>

    @Query("DELETE FROM Story")
    suspend fun deleteAll()
}