package com.example.submissonawalintermediate.my_database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface keyRemoteDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(remoteKey: List<keyRemote>)

    @Query("SELECT * FROM keyRemote WHERE id = :id")
    suspend fun getRemoteKeysId(id: String): keyRemote?

    @Query("DELETE FROM keyRemote")
    suspend fun deleteRemoteKeys()
}

