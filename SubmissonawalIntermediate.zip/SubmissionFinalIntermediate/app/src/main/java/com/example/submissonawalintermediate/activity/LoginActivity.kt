package com.example.submissonawalintermediate.activity

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.ViewModelProvider
import com.example.submissonawalintermediate.User.UserPreferences
import com.example.submissonawalintermediate.ViewModel.ViewModelFactory
import com.example.submissonawalintermediate.ViewModel.ViewModelLogin
import com.example.submissonawalintermediate.MainActivity
import com.example.submissonawalintermediate.databinding.ActivityLoginBinding
import com.example.submissonawalintermediate.utils.isValidEmail
import com.example.submissonawalintermediate.utils.validateMinLegth

class LoginActivity : AppCompatActivity() {
    private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

    private lateinit var binding: ActivityLoginBinding
    private lateinit var loginViewModel: ViewModelLogin

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.hide()

        loginViewModel = ViewModelProvider(this, ViewModelFactory(UserPreferences.getInstance(dataStore)))[ViewModelLogin::class.java]

        initializeUI()
    }

    private fun initializeUI() {
        playAnimation()
        setUpAction()
        observeLogin()
        buttonEnable()
        passwordEditText()
    }

    private fun setUpAction() {
        binding.loginButton.setOnClickListener {
            val email = binding.emailCustom.text
            val password = binding.passwordCustom.text
            when {
                email.isNullOrEmpty() -> {
                    Toast.makeText(this, "Harap isi email anda", Toast.LENGTH_SHORT).show()
                }
                password.isNullOrEmpty() -> {
                    Toast.makeText(this, "Harap isi password anda", Toast.LENGTH_SHORT).show()
                }
                else -> {
                    setUpLogin()
                    showLoading(true)
                }
            }
        }
        binding.registerBtn.setOnClickListener {
            val intent = Intent(this@LoginActivity, RegisterActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
            startActivity(intent)
        }
    }

    private fun setUpLogin() {
        binding.apply {
            val email = emailCustom.text.toString()
            val pass = passwordCustom.text.toString()
            loginViewModel.login(email, pass)
        }
    }

    private fun observeLogin() {
        loginViewModel.getLogin().observe(this) {
            if (it.error) {
                showLoading(false)
                Toast.makeText(this, it.message, Toast.LENGTH_SHORT).show()
            } else {
                showLoading(true)
                Toast.makeText(this, it.message, Toast.LENGTH_SHORT).show()
                val intent = Intent(this@LoginActivity, MainActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
                startActivity(intent)
                finish()
            }
        }
    }

    private fun playAnimation() {
        ObjectAnimator.ofFloat(binding.imageLogin, View.TRANSLATION_X, -30f, 30f).apply {
            duration = 6000
            repeatCount = ObjectAnimator.INFINITE
            repeatMode = ObjectAnimator.REVERSE
        }.start()

        val loginImage = ObjectAnimator.ofFloat(binding.imageLogin, View.ALPHA, 1f).setDuration(500)
        val txtLogin = ObjectAnimator.ofFloat(binding.textLogin, View.ALPHA, 1f).setDuration(500)
        val emailEditText = ObjectAnimator.ofFloat(binding.emailCustom, View.ALPHA, 1f).setDuration(500)
        val passwordEditTextLayout = ObjectAnimator.ofFloat(binding.passwordCustom, View.ALPHA, 1f).setDuration(500)
        val login = ObjectAnimator.ofFloat(binding.loginButton, View.ALPHA, 1f).setDuration(500)
        val register = ObjectAnimator.ofFloat(binding.registerBtn, View.ALPHA, 1f).setDuration(500)

        AnimatorSet().apply {
            playSequentially(loginImage, txtLogin, emailEditText, passwordEditTextLayout, login, register)
        }.start()
    }

    private fun showLoading(loading: Boolean) {
        binding.progressBar.visibility = if (loading) View.VISIBLE else View.GONE
    }

    private fun buttonEnable() {
        val emailEditText = binding.emailCustom.text
        val passwordEditText = binding.passwordCustom.text
        binding.loginButton.isEnabled =
            isValidEmail(emailEditText.toString()) && validateMinLegth(passwordEditText.toString())
    }

    private fun passwordEditText() {
        binding.passwordCustom.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                buttonEnable()
            }

            override fun afterTextChanged(s: Editable?) {
            }
        })
    }
}