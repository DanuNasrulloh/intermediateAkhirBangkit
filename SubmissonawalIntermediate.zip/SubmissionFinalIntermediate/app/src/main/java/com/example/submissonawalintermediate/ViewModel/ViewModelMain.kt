package com.example.submissonawalintermediate.ViewModel

import android.content.Context
import androidx.lifecycle.*
import androidx.paging.cachedIn
import com.example.submissonawalintermediate.Story.Story_repo
import com.example.submissonawalintermediate.User.ModelUser
import com.example.submissonawalintermediate.User.UserPreferences
import com.example.submissonawalintermediate.page.My_injection
import kotlinx.coroutines.launch

class ViewModelMain(
    private val userPreferences: UserPreferences,
    private val storyRepository: Story_repo
) : ViewModel() {

    fun getStoryPage(token: String) = storyRepository.getStory(token).cachedIn(viewModelScope)

    fun logout() {
        viewModelScope.launch {
            userPreferences.logout()
        }
    }

    fun getUser(): LiveData<ModelUser> {
        return userPreferences.getUser().asLiveData()
    }

    class ViewModelFactory(private val context: Context, private val userPreferences: UserPreferences) :
        ViewModelProvider.Factory {
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(ViewModelMain::class.java)) {
                @Suppress("UNCHECKED_CAST")
                return ViewModelMain(
                    userPreferences,
                    My_injection.provideRepository(context)
                ) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class")
        }
    }
}
