package com.example.submissonawalintermediate.activity

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.example.submissonawalintermediate.ViewModel.ViewModelRegister
import com.example.submissonawalintermediate.activity.LoginActivity
import com.example.submissonawalintermediate.databinding.ActivityRegisterBinding
import com.example.submissonawalintermediate.utils.isValidEmail
import com.example.submissonawalintermediate.utils.validateMinLegth

class RegisterActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRegisterBinding
    private lateinit var registerViewModel: ViewModelRegister

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.hide()

        registerViewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory())[ViewModelRegister::class.java]

        initializeUI()
    }

    private fun initializeUI() {
        observeRegister()
        setUpAction()
        playAnimation()
        passwordEditText()
    }

    private fun observeRegister() {
        registerViewModel.getRegister().observe(this) {
            if (it == null) {
                showLoading(true)
            } else {
                Toast.makeText(this, "${it.message}", Toast.LENGTH_SHORT).show()
                showLoading(false)
                val intent = Intent(this@RegisterActivity, LoginActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
                startActivity(intent)
                finish()
            }
        }
    }

    private fun buttonEnable() {
        val emailEditText = binding.emailCustom.text
        val passwordEditText = binding.passwordCustom.text
        binding.buttonRegister.isEnabled =
            isValidEmail(emailEditText.toString()) && validateMinLegth(passwordEditText.toString())
    }

    private fun playAnimation() {
        ObjectAnimator.ofFloat(binding.imageLogin, View.TRANSLATION_X, -30f, 30f).apply {
            duration = 6000
            repeatCount = ObjectAnimator.INFINITE
            repeatMode = ObjectAnimator.REVERSE
        }.start()

        val loginImage = ObjectAnimator.ofFloat(binding.imageLogin, View.ALPHA, 1f).setDuration(500)
        val txtRegister = ObjectAnimator.ofFloat(binding.textRegister, View.ALPHA, 1f).setDuration(500)
        val name = ObjectAnimator.ofFloat(binding.nama, View.ALPHA, 1f).setDuration(500)
        val emailEditText = ObjectAnimator.ofFloat(binding.emailCustom, View.ALPHA, 1f).setDuration(500)
        val passwordEditTextLayout = ObjectAnimator.ofFloat(binding.passwordCustom, View.ALPHA, 1f).setDuration(500)
        val Note = ObjectAnimator.ofFloat(binding.textNote, View.ALPHA, 1f).setDuration(500)
        val register = ObjectAnimator.ofFloat(binding.buttonRegister, View.ALPHA, 1f).setDuration(500)
        val login = ObjectAnimator.ofFloat(binding.buttonLogin, View.ALPHA, 1f).setDuration(500)
        AnimatorSet().apply {
            playSequentially(loginImage, txtRegister, name, emailEditText, passwordEditTextLayout, register, login, Note)
            startDelay = 500
        }.start()
    }

    private fun setUpAction() {
        binding.buttonRegister.setOnClickListener {
            val name = binding.nama.text
            val email = binding.emailCustom.text
            val password = binding.passwordCustom.text
            when {
                name.isEmpty() -> {
                    Toast.makeText(this, "Harap isi nama anda", Toast.LENGTH_SHORT).show()
                }
                email.isNullOrEmpty() -> {
                    Toast.makeText(this, "Harap isi email anda", Toast.LENGTH_SHORT).show()
                }
                password.isNullOrEmpty() -> {
                    Toast.makeText(this, "Isi password anda dengan benar", Toast.LENGTH_SHORT).show()
                }
                else -> {
                    setUpRegister()
                    showLoading(true)
                }
            }
        }
        binding.buttonLogin.setOnClickListener {
            val intent = Intent(this@RegisterActivity, LoginActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
            startActivity(intent)
        }
    }

    private fun passwordEditText() {
        binding.passwordCustom.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                buttonEnable()
            }

            override fun afterTextChanged(s: Editable?) {
            }
        })
    }

    private fun setUpRegister() {
        binding.apply {
            val name = nama.text.toString()
            val email = emailCustom.text.toString()
            val pass = passwordCustom.text.toString()

            registerViewModel.register(name, email, pass)
        }
    }

    private fun showLoading(loading: Boolean) {
        binding.progressBar.visibility = if (loading) View.VISIBLE else View.GONE
    }
}