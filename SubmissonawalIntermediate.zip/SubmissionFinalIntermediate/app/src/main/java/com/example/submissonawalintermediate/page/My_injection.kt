package com.example.submissonawalintermediate.page

import android.content.Context
import com.example.submissonawalintermediate.API.ApiConfig
import com.example.submissonawalintermediate.Story.Story_repo
import com.example.submissonawalintermediate.my_database.Database_story

object My_injection {
    fun provideRepository(context: Context): Story_repo {
        val apiService = ApiConfig.getApiService()
        val storyDatabase = Database_story.getDatabase(context)
        return Story_repo.getInstance(apiService, storyDatabase)
    }
}