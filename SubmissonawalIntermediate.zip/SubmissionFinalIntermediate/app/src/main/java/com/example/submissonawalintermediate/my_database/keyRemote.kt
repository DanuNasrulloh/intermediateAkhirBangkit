package com.example.submissonawalintermediate.my_database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "keyRemote")
data class keyRemote(
    @PrimaryKey
    val id: String,
    val prevKey: Int?,
    val nextKey: Int?
)
