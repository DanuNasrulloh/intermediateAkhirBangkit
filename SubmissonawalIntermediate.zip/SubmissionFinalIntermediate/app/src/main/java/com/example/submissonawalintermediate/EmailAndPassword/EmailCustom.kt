package com.example.submissonawalintermediate.EmailAndPassword

import android.content.Context
import android.graphics.Canvas
import android.text.Editable
import android.text.TextWatcher
import android.util.AttributeSet
import android.view.View
import androidx.appcompat.widget.AppCompatEditText
import com.example.submissonawalintermediate.utils.isValidEmail

class EmailCustom : AppCompatEditText {
    constructor(context: Context) : super(context) {
        init()
    }

    constructor(context: Context, attrs: AttributeSet) : super(context, attrs) {
        init()
    }

    constructor(context: Context, attrs: AttributeSet, defStyleAttr: Int) : super(context, attrs, defStyleAttr) {
        init()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        hint = "Email"
        textAlignment = View.TEXT_ALIGNMENT_VIEW_START
    }

    private fun init() {
        addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {}

            override fun afterTextChanged(s: Editable) {
                val emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+"

                if (isValidEmail(text.toString())) {
                    this@EmailCustom.error = null
                }
                else {
                    this@EmailCustom.error = "Email Tidak Valid"
                }

                when {
                    s.isEmpty() -> {
                        error = "Masukkan email"
                    }
                    !s.trim { it <= ' ' }
                        .matches(emailPattern.toRegex()) && s.isNotEmpty() -> {
                        error = "Email tidak valid"
                    }
                }
            }
        })
    }
}