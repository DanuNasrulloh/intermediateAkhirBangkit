package com.example.submissonawalintermediate


import androidx.annotation.VisibleForTesting
import androidx.lifecycle.LiveData
import androidx.lifecycle.Observer
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException


fun <T> LiveData<T>.getOrAwaitValue(
    time: Long = 2,
    timeUnit: TimeUnit = TimeUnit.SECONDS,
    afterObserve: () -> Unit = {}
): T {
    var data: T? = null
    val latch = CountDownLatch(1)

    val observer = object : Observer<T> {
        override fun onChanged(value: T) {
            data = value
            latch.countDown()
            this@getOrAwaitValue.removeObserver(this)
        }
    }

    this.observeForever(observer)

    try {
        afterObserve()
        if (!latch.await(time, timeUnit)) {
            throw InterruptedException("LiveData value was never set.")
        }
    } catch (e: InterruptedException) {
        throw RuntimeException("Interrupted while waiting for LiveData", e)
    }

    @Suppress("UNCHECKED_CAST")
    return data as T
}

