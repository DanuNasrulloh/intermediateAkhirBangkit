package com.example.submissonawalintermediate.ViewModel

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.paging.AsyncPagingDataDiffer
import androidx.paging.PagingData
import androidx.recyclerview.widget.ListUpdateCallback
import com.example.submissonawalintermediate.Adapter.AdapterStoryList
import com.example.submissonawalintermediate.DummyData
import com.example.submissonawalintermediate.MainDispatcherRule
import com.example.submissonawalintermediate.Response.Story
import com.example.submissonawalintermediate.Story.Story_repo
import com.example.submissonawalintermediate.User.UserPreferences
import com.example.submissonawalintermediate.getOrAwaitValue
import io.mockk.coEvery
import io.mockk.mockk
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.*
import org.junit.*
import org.junit.rules.TestRule

@ExperimentalCoroutinesApi
class ViewModelMainTest {

    @get:Rule
    val mainDispatcherRules = MainDispatcherRule()

    @get:Rule
    val instantExecutorRule: TestRule = InstantTaskExecutorRule()

    private val testDispatcher = UnconfinedTestDispatcher()
    private lateinit var storyRepository: Story_repo
    private lateinit var userPreferences: UserPreferences
    private lateinit var viewModel: ViewModelMain

    @Before
    fun setUp() {
        Dispatchers.setMain(testDispatcher)
        storyRepository = mockk()
        userPreferences = mockk()
        viewModel = ViewModelMain(userPreferences, storyRepository)
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    @Test
    fun `when Get Story Should Return Data`() = runTest {
        // Arrange
        val dummyStory = DummyData.generateDummyStories()
        val pagingData = PagingData.from(dummyStory)
        val expectedStory = MutableLiveData<PagingData<Story>>()
        expectedStory.value = pagingData

        coEvery { storyRepository.getStory("token") } returns expectedStory

        // Act
        val actualStory: PagingData<Story> = viewModel.getStoryPage("token").getOrAwaitValue()

        val differ = AsyncPagingDataDiffer(
            diffCallback = AdapterStoryList.DIFF_CALLBACK,
            updateCallback = noopListUpdateCallback,
            workerDispatcher = Dispatchers.Main
        )
        differ.submitData(actualStory)

        // Assert
        Assert.assertNotNull(differ.snapshot())
        Assert.assertEquals(dummyStory.size, differ.snapshot().size)
        Assert.assertEquals(dummyStory[0], differ.snapshot()[0])
    }

    @Test
    fun `when Get Story Empty Should Return No Data`() = runTest {
        // Arrange
        val emptyPagingData = PagingData.from(emptyList<Story>())
        val expectedStory = MutableLiveData<PagingData<Story>>()
        expectedStory.value = emptyPagingData

        coEvery { storyRepository.getStory("token") } returns expectedStory

        // Act
        val actualStory: PagingData<Story> = viewModel.getStoryPage("token").getOrAwaitValue()

        val differ = AsyncPagingDataDiffer(
            diffCallback = AdapterStoryList.DIFF_CALLBACK,
            updateCallback = noopListUpdateCallback,
            workerDispatcher = Dispatchers.Main
        )
        differ.submitData(actualStory)

        // Assert
        Assert.assertEquals(0, differ.snapshot().size)
    }

    private val noopListUpdateCallback = object : ListUpdateCallback {
        override fun onInserted(position: Int, count: Int) {}
        override fun onRemoved(position: Int, count: Int) {}
        override fun onMoved(fromPosition: Int, toPosition: Int) {}
        override fun onChanged(position: Int, count: Int, payload: Any?) {}
    }
}
