package com.example.submissonawalintermediate

import com.example.submissonawalintermediate.Response.Story
import kotlin.random.Random

object DummyData {

    fun generateDummyStories(): List<Story> {
        val items: MutableList<Story> = mutableListOf()

        for (i in 1..50) {
            val story = Story(
                photoUrl = generateRandomImageUrl(),
                createdAt = generateRandomDate(),
                name = "User $i",
                description = "This is a random description for story $i.",
                lon = generateRandomLongitude().toString(),
                id = "story_id_$i",
                lat = generateRandomLatitude().toString()
            )
            items.add(story)
        }

        return items
    }

    private fun generateRandomImageUrl(): String {
        val categories = listOf("nature", "city", "animals", "people", "abstract")
        val randomCategory = categories.random()
        return "https://source.unsplash.com/200x300/?$randomCategory&${Random.nextInt(1000)}"
    }

    private fun generateRandomDate(): String {
        val year = Random.nextInt(2020, 2022)
        val month = Random.nextInt(1, 10).toString().padStart(2, '0')
        val day = Random.nextInt(1, 20).toString().padStart(2, '0')
        val hour = Random.nextInt(0, 20).toString().padStart(2, '0')
        val minute = Random.nextInt(0, 40).toString().padStart(2, '0')
        val second = Random.nextInt(0, 40).toString().padStart(2, '0')

        return "$year-$month-${day}T$hour:$minute:$second"
    }

    private fun generateRandomLatitude(): Double {
        return Random.nextDouble(-90.0, 90.0)
    }

    private fun generateRandomLongitude(): Double {
        return Random.nextDouble(-180.0, 180.0)
    }
}